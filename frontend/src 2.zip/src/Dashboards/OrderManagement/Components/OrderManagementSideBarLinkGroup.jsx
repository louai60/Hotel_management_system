import React from 'react'

const OrderManagementSideBarLinkGroup = () => {
    return (
        <div>OrderManagementSideBarLinkGroup</div>
    )
}

export default OrderManagementSideBarLinkGroup