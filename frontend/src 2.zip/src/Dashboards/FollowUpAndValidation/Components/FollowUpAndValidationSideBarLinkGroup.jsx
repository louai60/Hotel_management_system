import React from 'react'

const FollowUpAndValidationSideBarLinkGroup = () => {
    return (
        <div>FollowUpAndValidationSideBarLinkGroup</div>
    )
}

export default FollowUpAndValidationSideBarLinkGroup