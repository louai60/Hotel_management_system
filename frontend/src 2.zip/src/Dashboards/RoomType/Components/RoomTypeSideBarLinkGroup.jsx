import React from 'react'

const RoomTypeSideBarLinkGroup = () => {
    return (
        <div>RoomTypeSideBarLinkGroup</div>
    )
}

export default RoomTypeSideBarLinkGroup