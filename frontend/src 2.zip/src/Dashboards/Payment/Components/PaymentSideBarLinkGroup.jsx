import React from 'react'

const PaymentSideBarLinkGroup = () => {
    return (
        <div>PaymentSideBarLinkGroup</div>
    )
}

export default PaymentSideBarLinkGroup