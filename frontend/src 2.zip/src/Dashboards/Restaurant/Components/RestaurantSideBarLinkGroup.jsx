import React from 'react'

const RestaurantSideBarLinkGroup = () => {
    return (
        <div>RestaurantSideBarLinkGroup</div>
    )
}

export default RestaurantSideBarLinkGroup