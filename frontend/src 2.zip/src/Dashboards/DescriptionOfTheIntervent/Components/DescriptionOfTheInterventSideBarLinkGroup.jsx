import React from 'react'

const DescriptionOfTheInterventSideBarLinkGroup = () => {
    return (
        <div>DescriptionOfTheInterventSideBarLinkGroup</div>
    )
}

export default DescriptionOfTheInterventSideBarLinkGroup