import React from 'react'

const AccountingSideBarLinkGroup = () => {
    return (
        <div>AccountingSideBarLinkGroup</div>
    )
}

export default AccountingSideBarLinkGroup