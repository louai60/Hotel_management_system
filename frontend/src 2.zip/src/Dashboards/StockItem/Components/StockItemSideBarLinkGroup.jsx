import React from 'react'

const StockItemSideBarLinkGroup = () => {
    return (
        <div>StockItemSideBarLinkGroup</div>
    )
}

export default StockItemSideBarLinkGroup