import React from 'react'

const CleaningDetailSideBarLinkGroup = () => {
    return (
        <div>CleaningDetailSideBarLinkGroup</div>
    )
}

export default CleaningDetailSideBarLinkGroup