import React from 'react'

const DashboardTemplate = () => {
  return (
    <div>DashboardTemplate</div>
  )
}

export default DashboardTemplate