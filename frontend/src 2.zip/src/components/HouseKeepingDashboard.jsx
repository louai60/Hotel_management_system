import React from 'react'

const HouseKeepingDashboard = () => {
  return (
    <div>HouseKeepingDashboard</div>
  )
}

export default HouseKeepingDashboard