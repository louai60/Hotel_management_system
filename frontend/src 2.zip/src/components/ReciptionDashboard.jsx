import React from 'react'

const ReciptionDashboard = () => {
  return (
    <div>ReciptionDashboard</div>
  )
}

export default ReciptionDashboard